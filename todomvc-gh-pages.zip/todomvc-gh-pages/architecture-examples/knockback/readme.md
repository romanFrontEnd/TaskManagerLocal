# Knockback.js • [TodoMVC](http://todomvc.com)

## Getting started

You need [CoffeScript](http://coffeescript.org) to compile if you make changes to the files in the `src` folder.


## Compile

Open Terminal in this folder.

- `cake build` to compile once

- `cake watch` to compile on save