var ENTER_KEY = 13;

$(function() {
  // Kick things off by creating the **App**.
  var view = new Thorax.Views['app']();
  $('body').append(view.el);
});
