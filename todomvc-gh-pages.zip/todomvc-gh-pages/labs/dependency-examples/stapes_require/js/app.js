require(
    ["controllers/todoController"],
    function(todoController) {
        todoController.init();
    }
);
