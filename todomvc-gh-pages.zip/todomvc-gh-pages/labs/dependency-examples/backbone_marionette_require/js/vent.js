define(['marionette'],function(marionette){
  "use strict";
  return new marionette.EventAggregator();
});
