# Knockout.js + Require.js • [TodoMVC](http://todomvc.com)

[loicknuchel](https://twitter.com/loicknuchel) adapt /architecture-examples/knockoutjs app with require.js
