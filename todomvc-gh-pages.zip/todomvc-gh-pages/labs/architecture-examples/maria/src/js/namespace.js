var checkit = checkit || {};
