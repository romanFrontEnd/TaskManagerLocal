# Epitome TodoMVC app

[Epitome](http://dimitarchristoff.github.com/Epitome) is a new extensible and modular open-source MVP* framework, built out of MooTools Classes and Events.
