# Olives • [TodoMVC](http://todomvc.com)

[Olives](http://flams.github.com/olives/) is a JS framework for creating real-time web applications, in no time.

Check out the [Wiki](https://github.com/flams/olives/wiki) for more information!

