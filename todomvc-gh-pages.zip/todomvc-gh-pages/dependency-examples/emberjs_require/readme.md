# Ember.js + Require.js • [TodoMVC](http://todomvc.com)


## Running tests

To fire specs runner, append `#specs` to the url in address bar, and reload the webpage.


## Credit

Initial release by @tomdale.

Refactoring and maintenance by @stas.
